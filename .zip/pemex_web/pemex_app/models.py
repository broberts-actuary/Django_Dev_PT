# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey has `on_delete` set to the desired behavior.
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models


class Applicability(models.Model):
    id = models.IntegerField(primary_key=True)
    desc_eng = models.CharField(max_length=100, blank=True, null=True)
    desc_esp = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'applicability'


class Assets(models.Model):
    id = models.IntegerField(primary_key=True)
    nam = models.CharField(max_length=100, blank=True, null=True)
    code = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'assets'


class Criteria(models.Model):
    id = models.IntegerField(primary_key=True)
    desc_eng = models.CharField(max_length=100, blank=True, null=True)
    desc_esp = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'criteria'


class FieldInputs(models.Model):
    id = models.IntegerField(primary_key=True)
    item = models.IntegerField(blank=True, null=True)
    applicability = models.IntegerField(blank=True, null=True)
    item_status = models.IntegerField(blank=True, null=True)
    input_user = models.IntegerField(blank=True, null=True)
    input_date = models.DateField(blank=True, null=True)
    input_comment = models.CharField(max_length=100, blank=True, null=True)
    seq_num = models.IntegerField(blank=True, null=True)
    next_responsible = models.IntegerField(blank=True, null=True)
    next_action = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'field_inputs'


class Files(models.Model):
    id = models.IntegerField(primary_key=True)
    filenam = models.CharField(max_length=100, blank=True, null=True)
    deleted = models.BinaryField(blank=True, null=True)
    upload_user = models.CharField(max_length=100, blank=True, null=True)
    upload_comment = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'files'


class InstImportLookup(models.Model):
    orig = models.CharField(max_length=10, blank=True, null=True)
    lookup = models.CharField(max_length=30, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'inst_import_lookup'


class Installations(models.Model):
    id = models.IntegerField(primary_key=True)
    nam = models.CharField(max_length=100, blank=True, null=True)
    asset = models.IntegerField(blank=True, null=True)
    processing_center = models.CharField(max_length=100, blank=True, null=True)
    platform_count = models.IntegerField(blank=True, null=True)
    latitude = models.FloatField(blank=True, null=True)
    longitude = models.FloatField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'installations'


class Items(models.Model):
    id = models.IntegerField(primary_key=True)
    installation = models.IntegerField(blank=True, null=True)
    recommendation = models.IntegerField(blank=True, null=True)
    verification = models.IntegerField(blank=True, null=True)
    criteria = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'items'


class Recommendations(models.Model):
    id = models.IntegerField(primary_key=True)
    nam = models.CharField(max_length=100, blank=True, null=True)
    prefix = models.CharField(max_length=100, blank=True, null=True)
    major = models.CharField(max_length=100, blank=True, null=True)
    minor = models.CharField(max_length=100, blank=True, null=True)
    part = models.CharField(max_length=100, blank=True, null=True)
    desc_eng = models.CharField(max_length=100, blank=True, null=True)
    desc_esp = models.CharField(max_length=100, blank=True, null=True)
    summary_eng = models.CharField(max_length=100, blank=True, null=True)
    summary_esp = models.CharField(max_length=100, blank=True, null=True)
    pep_responsible = models.CharField(max_length=100, blank=True, null=True)
    absg_responsible = models.CharField(max_length=100, blank=True, null=True)
    installation = models.CharField(max_length=100, blank=True, null=True)
    feild_verification = models.CharField(max_length=100, blank=True, null=True)
    interview = models.CharField(max_length=100, blank=True, null=True)
    sweetiening_plant = models.CharField(max_length=100, blank=True, null=True)
    drill = models.CharField(max_length=100, blank=True, null=True)
    crae = models.CharField(max_length=100, blank=True, null=True)
    cases = models.CharField(max_length=100, blank=True, null=True)
    abk_a2 = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'recommendations'


class Status(models.Model):
    id = models.IntegerField(primary_key=True)
    desc_eng = models.CharField(max_length=100, blank=True, null=True)
    desc_esp = models.CharField(max_length=100, blank=True, null=True)
    type_user = models.BinaryField(blank=True, null=True)
    type_rev = models.BinaryField(blank=True, null=True)
    next_action = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'status'


class Users(models.Model):
    id = models.IntegerField(primary_key=True)
    username = models.CharField(max_length=100, blank=True, null=True)
    passcode = models.CharField(max_length=100, blank=True, null=True)
    contact_phone = models.CharField(max_length=100, blank=True, null=True)
    contact_email = models.CharField(max_length=100, blank=True, null=True)
    type_user = models.BinaryField(blank=True, null=True)
    type_rev = models.BinaryField(blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'users'


class VerificationActions(models.Model):
    id = models.IntegerField(primary_key=True)
    desc_eng = models.CharField(max_length=100, blank=True, null=True)
    desc_esp = models.CharField(max_length=100, blank=True, null=True)

    class Meta:
        managed = True
        db_table = 'verification_actions'
