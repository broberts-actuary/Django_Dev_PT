from django.shortcuts import render


# Create your views here.
def upload(request):
    return render(request, 'UploadEvidence.html')


def assign(request):
    return render(request, 'AssignToItems.html')


def inputs(request):
    return render(request, 'FieldInputs.html')
