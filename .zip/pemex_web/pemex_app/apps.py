from django.apps import AppConfig


class PemexAppConfig(AppConfig):
    name = 'pemex_app'
